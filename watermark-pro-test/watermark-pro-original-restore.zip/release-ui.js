(()=>{
'use strict';
const q=s=>document.querySelector(s);
const style=document.createElement('style');
style.textContent=`
html body .topbar .header-brand-logo,html body #authPage .auth-page-brand-v53 .brandmark{width:40px!important;height:40px!important;min-width:40px!important;flex-basis:40px!important;border-radius:11px!important;object-fit:cover!important}
html body.pro-account:not(.owner-account) #headerProfileAvatar,html body.pro-account:not(.owner-account) #avatarPreview{overflow:visible!important}
html body.pro-account:not(.owner-account) #headerProfileAvatar::after,html body.pro-account:not(.owner-account) #avatarPreview::after{content:"";position:absolute;right:-3px;bottom:-3px;width:16px;height:16px;background:var(--wp-wmark-image) center/contain no-repeat!important;border:2px solid #f7f9fb;border-radius:50%;z-index:3}
html body.pro-account:not(.owner-account) #avatarPreview::after{width:20px;height:20px;right:0;bottom:0}
html body #mediaLightbox[data-viewer-kind="banner"] #closeMediaViewer,html body #mediaLightbox[data-viewer-kind="photo-banner"] #closeMediaViewer{left:50%!important;right:auto!important;transform:translateX(-50%)!important}
.wp-password-wrap{position:relative;display:block;min-width:0;width:100%}
html body .wp-password-wrap input{padding-right:76px!important;width:100%;box-sizing:border-box}
html body .wp-password-wrap .wp-password-toggle{position:absolute!important;right:6px;top:50%;transform:translateY(-50%);width:auto!important;min-width:0!important;min-height:32px!important;height:32px!important;padding:4px 8px!important;border:0!important;background:transparent!important;color:#315579!important;font:600 11px system-ui!important;box-shadow:none!important}
html body #passwordChangeStatus:not(:empty){display:block!important;padding:12px!important;background:#eef7ff!important;border-radius:10px;color:#174970}
.wp-community-link{display:inline-flex;align-items:center;gap:8px;text-decoration:none}
`;
document.head.append(style);
document.documentElement.style.setProperty('--wp-wmark-image','url("'+window.WPWMarkAsset+'")');
function mountPasswords(){
 document.querySelectorAll('input[type="password"]').forEach(input=>{
  if(input.closest('.wp-password-wrap'))return;
  const wrap=document.createElement('span');wrap.className='wp-password-wrap';input.before(wrap);wrap.append(input);
  const b=document.createElement('button');b.type='button';b.className='wp-password-toggle';b.textContent='Papar';b.setAttribute('aria-label','Papar kata laluan');b.setAttribute('aria-pressed','false');
  b.onclick=()=>{const show=input.type==='password';input.type=show?'text':'password';b.textContent=show?'Sorok':'Papar';b.setAttribute('aria-label',show?'Sorok kata laluan':'Papar kata laluan');b.setAttribute('aria-pressed',String(show));};wrap.append(b);
 });
}
mountPasswords();
const f=q('#passwordChangeForm');
if(f)f.onsubmit=async e=>{
 e.preventDefault();const form=e.currentTarget,status=q('#passwordChangeStatus'),button=form.querySelector('[type="submit"]');
 status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.textContent='Menyimpan…';button.disabled=true;
 try{
  const api=window.WPCloudflare?.api;if(!api)throw new Error('Sambungan akaun belum sedia. Cuba lagi.');
  const data=await api('/api/account/password',{method:'PATCH',body:JSON.stringify(Object.fromEntries(new FormData(form)))});
  if(data.token)localStorage.setItem('watermarkProUserApiToken',data.token);
  form.reset();form.querySelectorAll('.wp-password-wrap input').forEach(i=>i.type='password');form.querySelectorAll('.wp-password-toggle').forEach(b=>{b.textContent='Papar';b.setAttribute('aria-pressed','false')});
  status.textContent='Kata laluan berjaya disimpan.';status.scrollIntoView({block:'nearest'});
 }catch(error){status.textContent=error.message||'Kata laluan gagal disimpan.'}
 finally{button.disabled=false;}
};
function community(settings){
 let card=q('#communitySection');
 if(!card){const wa=q('#whatsappSupportBtn')?.closest('.card');if(!wa)return;card=document.createElement('section');card.className='card pad';card.id='communitySection';card.innerHTML='<div class="sectionhead"><div><h2>Sertai komuniti</h2><p>Ikuti berita dan kemas kini Watermark Pro.</p></div></div><a class="btn wp-community-link" target="_blank" rel="noopener noreferrer">Telegram channel</a><p class="community-empty">Pautan komuniti akan tersedia tidak lama lagi.</p>';wa.after(card);}
 const a=card.querySelector('a');let url;try{url=new URL(settings?.communityUrl)}catch{}
 const valid=url?.protocol==='https:'&&['t.me','telegram.me','www.t.me'].includes(url.hostname);
 a.hidden=!valid;card.querySelector('.community-empty').hidden=Boolean(valid);if(valid)a.href=url.href;
}
const routeMap={home:'',profile:'profil',subscriptions:'sokongan',settings:'tetapan'};
const fromPath=()=>Object.keys(routeMap).find(k=>routeMap[k]===location.pathname.replace(/^\/watermark-pro\/?/,'').replace(/\/$/,''))||'home';
let routeApplied=false;
const apply=window.WPApplyLiveState;
if(typeof apply==='function')window.WPApplyLiveState=(pub,acc)=>{
 apply(pub,acc);community(pub?.settings);mountPasswords();
 if(acc?.user&&!routeApplied){routeApplied=true;const page=fromPath();if(typeof openPage==='function')openPage(page);}
 if(!acc?.user)routeApplied=false;
};
document.addEventListener('click',e=>{
 const nav=e.target.closest('[data-page]');if(!nav||document.body.classList.contains('auth-mode'))return;
 const page=nav.dataset.page;if(!(page in routeMap))return;
 const path='/watermark-pro/'+routeMap[page];if(location.pathname!==path)history.pushState({page},'',path);
});
addEventListener('popstate',()=>{if(!document.body.classList.contains('auth-mode')&&typeof openPage==='function')openPage(fromPath());});
})();
