(()=>{
 const style=document.createElement('style');style.textContent='.identity-copy strong{display:inline-flex;align-items:center;gap:3px}.control-wmark{width:13px;height:auto;flex:0 0 13px}.password-toggle{margin-top:6px;font-size:12px}';document.head.append(style);
 document.querySelectorAll('input[type="password"]').forEach(input=>{const b=document.createElement('button');b.type='button';b.className='btn small password-toggle';b.textContent='Papar kata laluan';b.setAttribute('aria-pressed','false');input.after(b);b.onclick=()=>{const show=input.type==='password';input.type=show?'text':'password';b.textContent=show?'Sorok kata laluan':'Papar kata laluan';b.setAttribute('aria-pressed',String(show))}});
 const b=document.getElementById('resetUserPasswordBtn');b.onclick=async()=>{
  const id=document.getElementById('userId').value,input=document.getElementById('resetUserPassword'),status=document.getElementById('resetUserPasswordStatus');
  if(!id)return;if(input.value.length<8){status.textContent='Masukkan sekurang-kurangnya 8 aksara.';return;}
  if(!confirm('Identiti pengguna telah disahkan? Tukar kata laluan dan tamatkan semua sesi lamanya?'))return;
  b.disabled=true;status.textContent='Menyimpan…';
  try{const r=await window.WPControlCloudflare.resetPassword(id,input.value);input.value='';input.type='password';status.textContent=r.message;}catch(e){status.textContent=e.message||'Gagal menyimpan.';}finally{b.disabled=false;}
 };
})();
